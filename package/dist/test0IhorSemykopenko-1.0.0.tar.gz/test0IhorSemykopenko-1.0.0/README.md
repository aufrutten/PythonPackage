# Task_5_Semykopenko_Ihor

### <b>this package gives one function</b>

from an imported module, the function called is called "counting_unique_characters".

the function return number unique characters of string

exp: counting_unique_characters("abbcd") -> 3


### <b>if we call function from terminal</b>

called object is 'collect_framework.py' ask arguments of line
--string or --file
like: <p>python3 collect_framework.py --string 'Hello world'</p>

<p>or</p>
<p>python3 collect_framework.py --file text.txt</p>
the function have priority: 1) file 2) string. if you didn't write anything. function will call exception